#include "PS2.h"
#include <stdbool.h>
#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"
#include "time.h"
#include "graphics.h"

/* GLOBAL VARIABLES */

int score = 0;                // changed by game
int difficulty = 3;
int winScore;
int turnTracker = 0;  // 0 is Player, 1 is CPU
int defaultTime;
int hitTimer;
int speedupMultiplier = 0.95;

int currPos = 2;
int nextPos = 1;

int main() {
    startGraphics();

    setUpGame( 1, 500);
	while(1){
		updateFrame();
        PS_2INPUT();
		if(flagLeft == 1 || flagRight == 1){
			bounceBall(500, 3, 1);
		}
		if(gameBall.centre[2]<OPPONENT_LOC_Z){
			bounceBall(500, 1, 3);
		}
        flagLeft = 0;
        flagRight = 0;
	}

}